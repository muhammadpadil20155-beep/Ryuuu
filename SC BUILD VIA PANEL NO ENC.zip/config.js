module.exports = {
    bot: {
        token: "8722195720:AAF5lWLx5r80ACTW15zOYQrVui_6U_o-cWg",
        adminId: "8716243546"
    },
    github: {
        token: "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",
        owner: "ryuuu",
        repo: "web2apk-builder"
    },
    license: {
        "2K": { duration: 1, unit: "hour" },
        "5K": { duration: 7, unit: "hour" },
        "10K": { duration: 12, unit: "hour" },
        "15K": { duration: "permanent", unit: null }
    },
    server: { maxConcurrent: 5, buildTimeout: 600000, tempDir: "./temp" },
    verification: { enabled: true, channelUsername: "AboutGyzenLyoraaa", channelUrl: "https://t.me/InformationGyzen" },
    contact: { owner: "@RyuuuIzin", support: "@xhdbryuu" },
    texts: { welcome: "W9April2APK\nSelamat Datang, '{name}'!", features: "🏅 Fitur Premium:\n- Tanpa Iklan\n- Proses Cepat" }
};